import { useState, useEffect } from "react";
import DeleteButton from "./components/DeleteButton";

import axios from "axios";

const App = () => {
  const [notes, setNotes] = useState([]);

  const getNotes = () => {
    axios.get("http://localhost:3001/notes").then((response) => {
      setNotes(response.data);
    });
  };

  useEffect(getNotes, [notes]);

  return (
    <div>
      <h1>Notes</h1>
      {notes.map((note) => (
        <div key={note.id}>
          <ul>
            <li style={{ color: note.status ? "green" : "red" }}>{note.content}</li>
            <DeleteButton id={note.id} notes={notes} setNotes={setNotes} />{" "}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default App;
